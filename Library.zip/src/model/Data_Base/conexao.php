<?php

namespace Library_ETE\model\Data_Base;

use mysqli;

class Conexao
{
    private $endereco = "br418.hostgator.com.br";
    private $login = "etemfl83_ete_biblioteca";
    private $senha = "library?23";
    private $banco = "etemfl83_ete_biblioteca";

    public $mysqli;

    public function __construct()
    {
        $this->mysqli = new mysqli($this->endereco, $this->login, $this->senha, $this->banco);
    }

    public function __destruct()
    {
    }

    public function fecharConexao()
    {
        $this->mysqli->close();
        $this->__destruct();
    }

}
